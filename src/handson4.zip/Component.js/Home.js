import React from 'react';
import Nav from './Nav';
const Home = () => {
    return (
        <div>
            <Nav/>
            This Is My Home Page
        </div>
    );
}

export default Home;
