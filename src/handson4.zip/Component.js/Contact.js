import React from 'react';
import Nav from './Nav';
const Contact = () => {
    return (
        <>
         <Nav/>
            This Is My Contact Page
        </>
    );
}

export default Contact;
