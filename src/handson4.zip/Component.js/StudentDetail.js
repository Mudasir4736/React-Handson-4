import React from 'react';
import Nav from './Nav';
import { Link } from 'react-router-dom';
const StudentDetail = () => {
    return (
        <>
         <Nav/>
           
<div className='navbarheadbutton'>
    <span>
        Student Details
    </span>
    <button>
        Add New Student
    </button>
</div>

            <table border={"2px"}>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Age</th>
                        <th>Course</th>
                        <th>Batch</th>
                       <th><Link>Edit</Link></th> 
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Saleem</td>
                        <td>Saleem</td>
                        <td>Saleem</td>
                        <td>Saleem</td>
                        <td><Link>Edit</Link></td>
                    </tr>
                    <tr>
                        <td>Saleem</td>
                        <td>Saleem</td>
                        <td>Saleem</td>
                        <td>Saleem</td>
                        <td><Link>Edit</Link></td>
                    </tr>
                    <tr>
                        <td>Saleem</td>
                        <td>Saleem</td>
                        <td>Saleem</td>
                        <td>Saleem</td>
                        <td><Link>Edit</Link></td>
                    </tr>
                    <tr>
                        <td>Saleem</td>
                        <td>Saleem</td>
                        <td>Saleem</td>
                        <td>Saleem</td>
                        <td><Link>Edit</Link></td>
                    </tr>
                    <tr>
                        <td>Saleem</td>
                        <td>Saleem</td>
                        <td>Saleem</td>
                        <td>Saleem</td>
                        <td><Link>Edit</Link></td>
                    </tr>

                    <tr>
                        <td>Saleem</td>
                        <td>Saleem</td>
                        <td>Saleem</td>
                        <td>Saleem</td>
                        <td><Link>Edit</Link></td>
                    </tr>

                    <tr>
                        <td>Saleem</td>
                        <td>Saleem</td>
                        <td>Saleem</td>
                        <td>Saleem</td>
                        <td><Link>Edit</Link></td>
                    </tr>
                    <tr>
                        <td>Saleem</td>
                        <td>Saleem</td>
                        <td>Saleem</td>
                        <td>Saleem</td>
                        <td><Link>Edit</Link></td>
                    </tr>

                    <tr>
                        <td>Saleem</td>
                        <td>Saleem</td>
                        <td>Saleem</td>
                        <td>Saleem</td>
                        <td><Link>Edit</Link></td>
                    </tr>
                    <tr>
                        <td>Saleem</td>
                        <td>Saleem</td>
                        <td>Saleem</td>
                        <td>Saleem</td>
                        <td><Link>Edit</Link></td>
                    </tr>
                </tbody>
            </table>



        </>
    );
}

export default StudentDetail;
